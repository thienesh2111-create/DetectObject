import swiftbot.*;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.Random;

// ╔══════════════════════════════════════════════════════════════════╗
// ║           DETECT OBJECT — CS1814 Software Implementation        ║
// ║                       Task 10 — SwiftBot                        ║
// ║  Modes: Curious | Scaredy | Dubious                             ║
// ╚══════════════════════════════════════════════════════════════════╝

// =============================================================================
// INTERFACE: Behaviour
// Defines the contract for all behaviour types (Strategy Design Pattern).
// Any new behaviour only needs to implement this one method.
// =============================================================================
interface Behaviour {
    /**
     * Triggered when an object is detected within range.
     * @param distance  Distance to object in cm
     * @param bot       Live SwiftBotAPI instance for hardware control
     * @param logger    LoggerService for recording events
     */
    void trigger(int distance, SwiftBotAPI bot, LoggerService logger);
}

// =============================================================================
// ENUM: Mode
// Represents the three valid operating modes.
// Using an enum prevents invalid mode values at compile time.
// =============================================================================
enum Mode {
    CURIOUS("Curious SwiftBot"),
    SCAREDY("Scaredy SwiftBot"),
    DUBIOUS("Dubious SwiftBot");

    private final String label; // private: access only through getLabel()

    Mode(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** Returns true if input exactly matches a known mode label (case-sensitive). */
    public static boolean isValidLabel(String input) {
        for (Mode m : values()) {
            if (m.label.equals(input)) return true;
        }
        return false;
    }

    /** Converts a valid label string to its Mode enum constant. */
    public static Mode fromLabel(String input) {
        for (Mode m : values()) {
            if (m.label.equals(input)) return m;
        }
        return null;
    }
}

// =============================================================================
// CLASS: LoggerService
// Handles all file-based logging for the session.
// Private fields with controlled public access (encapsulation).
// =============================================================================
class LoggerService {

    private final StringBuilder logBuilder = new StringBuilder();
    private long startTimeMillis;
    private Mode mode;
    private int imageCount = 0;
    private String logFilePath;

    /**
     * Starts a new logging session. Records mode and start time.
     * @param mode The active SwiftBot mode
     */
    public void startLog(Mode mode) {
        this.mode = mode;
        this.startTimeMillis = System.currentTimeMillis();
        logBuilder.append("=== Detect Object Log ===\n");
        logBuilder.append("Mode: ").append(mode.getLabel()).append("\n");
        logBuilder.append("Start: ").append(formatTime(startTimeMillis)).append("\n");
    }

    /**
     * Records an event into the log buffer.
     * Auto-increments imageCount when an image path is included.
     * @param event Description of the event
     */
    public void recordEvent(String event) {
        logBuilder.append("[EVENT] ").append(event).append("\n");
        if (event.contains("image:")) imageCount++;
    }

    /**
     * Finalises the log, writes to file, and prints summary.
     * Called once on program termination.
     */
    public void endLog() {
        long endTimeMillis = System.currentTimeMillis();
        long durationSeconds = (endTimeMillis - startTimeMillis) / 1000;

        logBuilder.append("End: ").append(formatTime(endTimeMillis)).append("\n");
        logBuilder.append("Duration: ").append(durationSeconds).append(" seconds\n");
        logBuilder.append("Images saved: ").append(imageCount).append("\n");

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date(startTimeMillis));
        logFilePath = "swiftbot_logs/log_" + timestamp + ".txt";

        new java.io.File(logFilePath).getParentFile().mkdirs(); // create logs/ dir if needed

        try (FileWriter writer = new FileWriter(logFilePath)) {
            writer.write(logBuilder.toString());
        } catch (IOException e) {
            // Report file write failure without crashing the program
            System.out.println("[ERROR] Could not write log file: " + e.getMessage());
            System.out.println("[INFO]  Check that swiftbot_logs/ is writable.");
        }

        System.out.println();
        System.out.println("=== Session Summary ===");
        System.out.println("Mode     : " + mode.getLabel());
        System.out.println("Runtime  : " + durationSeconds + " seconds");
        System.out.println("Images   : " + imageCount);
        System.out.println("Log file : " + logFilePath);
        System.out.println("=======================");
        System.out.println();
    }

    /** Formats a millisecond timestamp to a readable date-time string. */
    private String formatTime(long millis) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(millis));
    }
}

// =============================================================================
// CLASS: CuriousBehaviour  (implements Behaviour)
// Maintains a 30 cm buffer zone:
//   - Too close  -> reverse away
//   - Too far    -> move forward
//   - Exact 30cm -> blink green and stay
// Captures an image after each action.
// =============================================================================
class CuriousBehaviour implements Behaviour {

    private static final int BUFFER_ZONE_CM = 30;

    // RGB array for GREEN underlights — used throughout this behaviour
    private static final int[] GREEN = {0, 255, 0};
    private static final int[] OFF   = {0, 0, 0};

    @Override
    public void trigger(int distance, SwiftBotAPI bot, LoggerService logger) {
        System.out.println();
        System.out.println("[EVENT] Object detected (CURIOUS mode)");
        System.out.println("  Distance : " + distance + " cm");
        System.out.println("  Buffer   : " + BUFFER_ZONE_CM + " cm");

        try {
            setAllUnderlights(bot, GREEN);

            if (distance < BUFFER_ZONE_CM) {
                // Object inside buffer zone — reverse away
                System.out.println("  Action   : Too close — reversing");
                bot.startMove(-50, -50); // negative values = backwards
                Thread.sleep(800);       // tune this via calibration
                bot.stopMove();

            } else if (distance > BUFFER_ZONE_CM) {
                // Object beyond buffer zone — move forward
                System.out.println("  Action   : Too far — moving forward");
                bot.startMove(50, 50);
                Thread.sleep(800);
                bot.stopMove();

            } else {
                // Exactly at buffer zone — blink green and stay still
                System.out.println("  Action   : At buffer zone — blinking green");
                for (int i = 0; i < 3; i++) {
                    setAllUnderlights(bot, GREEN);
                    Thread.sleep(300);
                    setAllUnderlights(bot, OFF);
                    Thread.sleep(300);
                }
            }

            setAllUnderlights(bot, OFF);

            // Capture and log image after movement
            String imagePath = captureImage(bot, "curious");
            logger.recordEvent("Curious encounter at " + distance + "cm, image: " + imagePath);
            System.out.println("  Image    : " + imagePath);

        } catch (InterruptedException e) {
            System.out.println("[WARN] Curious behaviour interrupted: " + e.getMessage());
            bot.stopMove();
        }
        System.out.println();
    }

    private static final String IMAGE_DIR          = "swiftbot_images";
    private static final int    SENSOR_RETRY_COUNT = 3;

    /**
     * Captures a photo with retry logic — up to SENSOR_RETRY_COUNT attempts.
     * @param bot        Live SwiftBotAPI instance
     * @param modePrefix "curious" or "scaredy" — included in filename for clarity
     * @return Absolute path of saved image, or placeholder string if all attempts fail
     */
    private String captureImage(SwiftBotAPI bot, String modePrefix) {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String filename  = IMAGE_DIR + java.io.File.separator
                + modePrefix + "_" + timestamp + ".jpg";

        new java.io.File(IMAGE_DIR).mkdirs(); // ensure directory exists

        for (int attempt = 1; attempt <= SENSOR_RETRY_COUNT; attempt++) {
            try {
                java.awt.image.BufferedImage img = bot.takeStill(ImageSize.SQUARE_480x480);
                if (img != null) {
                    java.io.File outFile = new java.io.File(filename);
                    javax.imageio.ImageIO.write(img, "jpg", outFile);
                    System.out.println("[IMAGE] Saved: " + outFile.getAbsolutePath());
                    return outFile.getAbsolutePath();
                }
            } catch (Exception e) {
                System.out.println("[WARN] Image capture attempt " + attempt
                        + " of " + SENSOR_RETRY_COUNT + " failed: " + e.getMessage());
                if (attempt < SENSOR_RETRY_COUNT) {
                    try { Thread.sleep(300); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
        }
        System.out.println("[ERROR] Image capture failed after " + SENSOR_RETRY_COUNT + " attempts.");
        return filename + " (capture failed)";
    }

    /** Sets all underlights using a single bulk call (safer than per-LED). */
    private void setAllUnderlights(SwiftBotAPI bot, int[] rgb) {
        try {
            bot.fillUnderlights(rgb);
        } catch (Exception e) {
            System.out.println("[WARN] Could not set underlights: " + e.getMessage());
        }
    }
}

// =============================================================================
// CLASS: ScaredyBehaviour  (implements Behaviour)
// When object detected within 50 cm:
//   1. Takes photo
//   2. Blinks red underlights
//   3. Reverses and turns away
//   4. Flees forward for 3 seconds
// =============================================================================
class ScaredyBehaviour implements Behaviour {

    private static final int[] RED  = {255, 0, 0};
    private static final int[] OFF  = {0, 0, 0};

    @Override
    public void trigger(int distance, SwiftBotAPI bot, LoggerService logger) {
        System.out.println();
        System.out.println("[EVENT] Object detected (SCAREDY mode)");
        System.out.println("  Distance : " + distance + " cm");
        System.out.println("  Action   : Flee sequence starting");

        try {
            // Step 1: Capture image before reacting
            String imagePath = captureImage(bot, "scaredy");
            logger.recordEvent("Scaredy encounter at " + distance + "cm, image: " + imagePath);
            System.out.println("  Image    : " + imagePath);

            // Step 2: Blink red underlights (alarm)
            System.out.println("  Lights   : Blinking RED");
            for (int i = 0; i < 3; i++) {
                setAllUnderlights(bot, RED);
                Thread.sleep(250);
                setAllUnderlights(bot, OFF);
                Thread.sleep(250);
            }

            // Step 3: Reverse away
            System.out.println("  Motion   : Reversing");
            setAllUnderlights(bot, RED);
            bot.startMove(-60, -60);
            Thread.sleep(1000);
            bot.stopMove();

            // Step 4: Spin to turn away (~90 degrees; tune sleep for your robot)
            System.out.println("  Motion   : Turning away");
            bot.startMove(-60, 60); // spin right: left wheel back, right wheel forward
            Thread.sleep(600);
            bot.stopMove();

            // Step 5: Flee forward for 3 seconds
            System.out.println("  Motion   : Fleeing for 3 seconds");
            bot.startMove(60, 60);
            Thread.sleep(3000);
            bot.stopMove();
            setAllUnderlights(bot, OFF);

        } catch (InterruptedException e) {
            System.out.println("[WARN] Scaredy behaviour interrupted: " + e.getMessage());
            bot.stopMove();
            setAllUnderlights(bot, OFF);
        }
        System.out.println();
    }

    private static final String IMAGE_DIR_S         = "swiftbot_images";
    private static final int    SENSOR_RETRY_COUNT_S = 3;

    /**
     * Captures a photo with retry logic — up to SENSOR_RETRY_COUNT_S attempts.
     * @param bot        Live SwiftBotAPI instance
     * @param modePrefix "curious" or "scaredy" — included in filename for clarity
     * @return Absolute path of saved image, or placeholder string if all attempts fail
     */
    private String captureImage(SwiftBotAPI bot, String modePrefix) {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String filename  = IMAGE_DIR_S + java.io.File.separator
                + modePrefix + "_" + timestamp + ".jpg";

        new java.io.File(IMAGE_DIR_S).mkdirs(); // ensure directory exists

        for (int attempt = 1; attempt <= SENSOR_RETRY_COUNT_S; attempt++) {
            try {
                java.awt.image.BufferedImage img = bot.takeStill(ImageSize.SQUARE_480x480);
                if (img != null) {
                    java.io.File outFile = new java.io.File(filename);
                    javax.imageio.ImageIO.write(img, "jpg", outFile);
                    System.out.println("[IMAGE] Saved: " + outFile.getAbsolutePath());
                    return outFile.getAbsolutePath();
                }
            } catch (Exception e) {
                System.out.println("[WARN] Image capture attempt " + attempt
                        + " of " + SENSOR_RETRY_COUNT_S + " failed: " + e.getMessage());
                if (attempt < SENSOR_RETRY_COUNT_S) {
                    try { Thread.sleep(300); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
        }
        System.out.println("[ERROR] Image capture failed after " + SENSOR_RETRY_COUNT_S + " attempts.");
        return filename + " (capture failed)";
    }

    /** Sets all underlights using a single bulk call (safer than per-LED). */
    private void setAllUnderlights(SwiftBotAPI bot, int[] rgb) {
        try {
            bot.fillUnderlights(rgb);
        } catch (Exception e) {
            System.out.println("[WARN] Could not set underlights: " + e.getMessage());
        }
    }
}

// =============================================================================
// CLASS: DubiousBehaviour  (implements Behaviour)
// Randomly picks and delegates to Curious or Scaredy at runtime.
// Demonstrates polymorphism: holds Behaviour interface references and calls
// trigger() without knowing which concrete class runs — decided at runtime.
// =============================================================================
class DubiousBehaviour implements Behaviour {

    // Held as Behaviour interface references — polymorphism in action
    private final Behaviour curious = new CuriousBehaviour();
    private final Behaviour scaredy = new ScaredyBehaviour();
    private final Random random = new Random();

    @Override
    public void trigger(int distance, SwiftBotAPI bot, LoggerService logger) {
        System.out.println();
        System.out.println("[EVENT] Object detected (DUBIOUS mode)");
        System.out.println("  Distance : " + distance + " cm");

        boolean actCurious = random.nextBoolean();

        if (actCurious) {
            System.out.println("  Decision : Randomly chose CURIOUS behaviour");
            curious.trigger(distance, bot, logger);
            logger.recordEvent("Dubious acted as CURIOUS at " + distance + "cm");
        } else {
            System.out.println("  Decision : Randomly chose SCAREDY behaviour");
            scaredy.trigger(distance, bot, logger);
            logger.recordEvent("Dubious acted as SCAREDY at " + distance + "cm");
        }
    }
}

// =============================================================================
// CLASS: SwiftBotSystem
// Core controller. Manages the main survey loop:
//   - Wanders with blue underlights
//   - Reads ultrasound sensor
//   - Delegates to the correct Behaviour (Strategy Pattern)
//   - Tracks encounters and prompts at the limit
//   - Listens for X button to stop (event-driven via enableButton callback)
// =============================================================================
class SwiftBotSystem {

    // Private fields: access controlled through public methods (encapsulation)
    private Mode mode;
    private final SwiftBotAPI bot;
    private final LoggerService logger;

    // Named constants instead of magic numbers (improves readability)
    private static final int CURIOUS_TRIGGER_CM = 30;
    private static final int SCAREDY_TRIGGER_CM = 50;
    private static final int ENCOUNTER_LIMIT    = 3;
    private static final int WANDERING_SPEED    = 40;

    // RGB colour constants
    private static final int[] BLUE = {0, 0, 255};
    private static final int[] OFF  = {0, 0, 0};

    private int encounters = 0;

    // Volatile flag set by X button callback — checked by the main polling loop.
    // volatile ensures the main thread sees updates made by the callback thread.
    private volatile boolean xPressed = false;

    public SwiftBotSystem(SwiftBotAPI bot, LoggerService logger) {
        this.bot    = bot;
        this.logger = logger;
    }

    /** Sets the operating mode. Called after QR code validation. */
    public void setMode(Mode mode) {
        this.mode = mode;
    }

    /**
     * Starts the main survey loop.
     * Wanders with blue underlights until an object triggers a Behaviour.
     * Exits when X is pressed or user chooses to terminate.
     *
     * The X button is monitored via an event-driven callback registered with
     * enableButton(). When the button fires, it sets the volatile xPressed
     * flag which the polling loop checks on each iteration.
     */
    public void run() {
        logger.startLog(mode);
        printStatus();

        // Register X button callback — sets flag AND stops motors immediately.
        // Calling stopMove() here (on the button-listener thread) ensures the
        // robot halts as fast as possible, without waiting for the main loop to
        // wake up from a Thread.sleep() inside a behaviour.
        bot.enableButton(Button.X, () -> {
            System.out.println("[STOP] X button pressed — shutting down.");
            xPressed = true;
            try { bot.stopMove(); } catch (Exception ignored) {}
        });

        // Begin wandering: blue lights, low forward speed
        setAllUnderlights(BLUE);
        bot.startMove(WANDERING_SPEED, WANDERING_SPEED);

        boolean running = true;

        while (running) {
            try {
                // Check X button flag (set by callback above)
                if (xPressed) {
                    running = false;
                    break;
                }

                // Read ultrasound distance sensor.
                // useUltrasound() can throw IOException on timeout — catch it
                // and skip this iteration rather than crashing the whole program.
                int distance;
                try {
                    distance = (int) bot.useUltrasound();
                } catch (java.io.IOException e) {
                    System.out.println("[WARN] Ultrasound timeout — skipping reading.");
                    Thread.sleep(100);
                    continue;
                }

                // Skip invalid readings (0 or negative)
                if (distance <= 0) {
                    Thread.sleep(100);
                    continue;
                }

                // Check whether this distance triggers the active mode
                Behaviour behaviourToUse = selectBehaviour(distance);

                if (behaviourToUse != null) {
                    // Pause wandering, execute behaviour, then resume
                    bot.stopMove();
                    setAllUnderlights(OFF);

                    behaviourToUse.trigger(distance, bot, logger);
                    encounters++;
                    System.out.println("Encounters so far: " + encounters);

                    // Resume wandering after behaviour completes
                    setAllUnderlights(BLUE);
                    bot.startMove(WANDERING_SPEED, WANDERING_SPEED);
                }

                // Check if encounter limit has been reached
                if (encounters >= ENCOUNTER_LIMIT) {
                    bot.stopMove();
                    setAllUnderlights(OFF);
                    running = handleEncounterLimit();

                    if (running) {
                        encounters = 0;
                        printStatus();
                        setAllUnderlights(BLUE);
                        bot.startMove(WANDERING_SPEED, WANDERING_SPEED);
                    }
                }

                Thread.sleep(100); // small poll delay to avoid busy-waiting

            } catch (InterruptedException e) {
                System.out.println("[WARN] Main loop interrupted: " + e.getMessage());
                running = false;
            } catch (Exception e) {
                // Catch any other unexpected exception so the loop keeps running
                System.out.println("[WARN] Unexpected error in main loop: " + e.getMessage());
            }
        }

        // Unregister button listener before shutting down
        bot.disableButton(Button.X);
        terminate();
    }

    // -------------------------------------------------------------------------
    // PRIVATE HELPERS — kept private to restrict access (access control)
    // -------------------------------------------------------------------------

    /**
     * Returns the correct Behaviour for the current mode and distance.
     * Returns null if the distance does not meet the trigger threshold.
     */
    private Behaviour selectBehaviour(int distance) {
        switch (mode) {
            case CURIOUS:
                if (distance <= CURIOUS_TRIGGER_CM) return new CuriousBehaviour();
                break;
            case SCAREDY:
                if (distance <= SCAREDY_TRIGGER_CM) return new ScaredyBehaviour();
                break;
            case DUBIOUS:
                if (distance <= SCAREDY_TRIGGER_CM) return new DubiousBehaviour();
                break;
        }
        return null;
    }

    /**
     * Shows the encounter-limit menu and handles user choice.
     * @return true = keep running (mode changed), false = terminate
     */
    private boolean handleEncounterLimit() {
        System.out.println();
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║  ALERT: Encounter limit reached (" + ENCOUNTER_LIMIT + ")      ║");
        System.out.println("║  [1] Change mode                         ║");
        System.out.println("║  [2] Terminate program                   ║");
        System.out.println("╚══════════════════════════════════════════╝");

        Scanner sc = new Scanner(System.in);
        int choice = readIntInRange(sc, "Selection > ", 1, 2);

        if (choice == 1) {
            System.out.println("[INFO] Scan a QR code or type the mode name and press ENTER:");
            System.out.println("  Curious SwiftBot | Scaredy SwiftBot | Dubious SwiftBot");

            String newLabel = null;

            while (newLabel == null || !Mode.isValidLabel(newLabel)) {
                // Try QR camera for up to 10 seconds
                newLabel = DetectObject.tryReadQR(bot);

                if (newLabel == null) {
                    // QR gave nothing after all attempts — use keyboard
                    System.out.println("[INFO] No QR detected. Type one of these EXACTLY and press ENTER:");
                    System.out.println("  -> Curious SwiftBot");
                    System.out.println("  -> Scaredy SwiftBot");
                    System.out.println("  -> Dubious SwiftBot");
                    System.out.print("Mode > ");
                    newLabel = sc.nextLine().trim();
                }

                if (!Mode.isValidLabel(newLabel)) {
                    System.out.println("[ERROR] Invalid mode: \"" + newLabel + "\"");
                    System.out.println("        Valid: Curious SwiftBot | Scaredy SwiftBot | Dubious SwiftBot");
                    newLabel = null;
                }
            }

            this.mode = Mode.fromLabel(newLabel);
            logger.recordEvent("Mode changed to: " + mode.getLabel());
            System.out.println("[INFO] Mode changed to: " + mode.getLabel());
            return true;

        } else {
            return false;
        }
    }

    /**
     * Reads an integer from the console within [min, max].
     * Loops until valid input given. Handles NumberFormatException safely.
     */
    private int readIntInRange(Scanner sc, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) return value;
                System.out.println("[ERROR] Enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] \"" + line + "\" is not a valid number.");
            }
        }
    }

    /** Prints current mode, status, and encounter count. */
    private void printStatus() {
        System.out.println();
        System.out.println("STATUS    : RUNNING");
        System.out.println("Mode      : " + mode.getLabel());
        System.out.println("Lights    : BLUE (wandering)");
        System.out.println("Encounters: " + encounters);
        System.out.println();
    }

    /** Stops all hardware, finalises the log, prints termination message. */
    private void terminate() {
        System.out.println();
        System.out.println("Stopping motors ...");
        bot.stopMove();
        System.out.println("Turning underlights OFF ...");
        setAllUnderlights(OFF);
        logger.endLog();
        System.out.println("Program terminated.");
    }

    /** Sets all underlights using a single bulk call (safer than per-LED). */
    private void setAllUnderlights(int[] rgb) {
        try {
            bot.fillUnderlights(rgb);
        } catch (Exception e) {
            System.out.println("[WARN] Could not set underlights: " + e.getMessage());
        }
    }
}

// =============================================================================
// CLASS: DetectObject  (entry point — public class must match filename)
// Prints header, prompts for mode, validates input, launches SwiftBotSystem.
// =============================================================================
public class DetectObject {

    public static void main(String[] args) {

        // ASCII art header
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║      SWIFTBOT  —  DETECT OBJECT PROGRAM      ║");
        System.out.println("║        CS1814 Software Implementation        ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.println();

        // Initialise SwiftBot hardware — SwiftBotAPI is a singleton enum
        SwiftBotAPI bot = SwiftBotAPI.INSTANCE;

        Scanner scanner = new Scanner(System.in);

        // ── Mode Selection: QR code with keyboard fallback ───────────────────
        // Each iteration calls tryReadQR() once. If the camera decodes a valid
        // string it is returned immediately. If the camera is unavailable or
        // sees nothing, tryReadQR() returns null and we fall back to a plain
        // blocking keyboard read. Both paths then validate the input.
        // ─────────────────────────────────────────────────────────────────────
        System.out.println("Scan a QR code OR type the mode name and press ENTER.");
        System.out.println("Valid modes:");
        System.out.println("  Curious SwiftBot");
        System.out.println("  Scaredy SwiftBot");
        System.out.println("  Dubious SwiftBot");
        System.out.println();

        Mode selectedMode = null;

        while (selectedMode == null) {
            // Try QR camera for up to 10 seconds
            String modeInput = tryReadQR(bot);

            if (modeInput == null) {
                // QR gave nothing after all attempts — use keyboard
                System.out.println("[INFO] No QR detected. Type one of these EXACTLY and press ENTER:");
                System.out.println("  -> Curious SwiftBot");
                System.out.println("  -> Scaredy SwiftBot");
                System.out.println("  -> Dubious SwiftBot");
                System.out.print("Mode > ");
                modeInput = scanner.nextLine().trim();
            }

            if (Mode.isValidLabel(modeInput)) {
                selectedMode = Mode.fromLabel(modeInput);
                System.out.println("[INFO] Mode selected: " + selectedMode.getLabel());
            } else {
                System.out.println("[ERROR] \"" + modeInput + "\" is not a valid mode.");
                System.out.println("        Expected: Curious SwiftBot | Scaredy SwiftBot | Dubious SwiftBot");
            }
        }

        System.out.println();
        System.out.println("[INFO] Press ENTER to begin, or type X to cancel.");
        String confirm = scanner.nextLine().trim();

        if (confirm.equalsIgnoreCase("X")) {
            System.out.println("[INFO] Start cancelled. Exiting.");
            scanner.close();
            return; // FIX: was 'break' (compile error — break is invalid outside a loop)
        }

        // Build and start the system
        LoggerService logger = new LoggerService();
        SwiftBotSystem system = new SwiftBotSystem(bot, logger);
        system.setMode(selectedMode);
        system.run();

        scanner.close();
    }

    /**
     * Attempts one QR scan from the camera.
     * Returns the decoded string if successful, or null if the camera is
     * unavailable, returns no image, or decodes nothing.
     * Caller falls back to keyboard when this returns null.
     */
    /**
     * Tries to read a mode via QR camera for up to 10 seconds (5 attempts x 2s).
     * Returns the decoded string immediately if successful.
     * Returns null if all attempts fail — caller should then use keyboard input.
     */
    static String tryReadQR(SwiftBotAPI bot) {
        final int MAX_ATTEMPTS = 5;
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try {
                System.out.println("[QR] Scan attempt " + attempt + " of " + MAX_ATTEMPTS + "...");
                java.awt.image.BufferedImage img = bot.getQRImage();
                if (img != null) {
                    String decoded = bot.decodeQRImage(img);
                    if (decoded != null && !decoded.trim().isEmpty()) {
                        System.out.println("[QR] Decoded: \"" + decoded.trim() + "\"");
                        return decoded.trim();
                    }
                }
                System.out.println("[QR] Nothing detected. Hold the code steady...");
            } catch (Exception e) {
                System.out.println("[QR] Camera error: " + e.getMessage());
            }
            // Wait 2s between attempts — but give up early if last attempt
            if (attempt < MAX_ATTEMPTS) {
                try { Thread.sleep(2000); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }
        }
        System.out.println("[QR] No QR code detected after " + MAX_ATTEMPTS + " attempts.");
        return null;
    }
}
